﻿
namespace WindowsFormsApp3
{
    using System.Collections.Generic;
    public interface IColorFormat
    {
        IList<ColorFormat> ColorFormats { get; set; }
    }


    public interface IColorFormat1
    {
        IList<ColorFormat1> ColorFormats1 { get; set; }
    }


}