﻿
namespace WindowsFormsApp3
{
using System;
using System.Drawing;
public class ColorFormat
{
    public Color Color { get; set; }
        public Color Color1 { get; set; }
        public Predicate<DateTime> Predicate { get; set; }
        public Predicate<DateTime> Predicate1 { get; set; }
    }

    public class ColorFormat1
    {
        public Color Color { get; set; }
        public Predicate<DateTime> Predicate1 { get; set; }
    }

}
